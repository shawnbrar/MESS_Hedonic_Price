
This toolbox has been written by N. Debarsy and C. Ertur, it includes estimation 
of fixed effects spatial panel data models based on the methodology developed by 
Lung-Fei Lee and Jihai Yu (Journal of Econometrics, 2010, 154, 165-185)
as well as LM and LR tests developed by N. Debarsy and C. Ertur "Testing for 
Spatial Autocorrelation in a Fixed Effects Panel Data Model" 
(LEO Working Paper n�2009-12 - halshs-00414133_v1) that can be downloaded from REPEC.

It is based on previous codes elaborated by J.P. Elhorst and J.P. LeSage.

